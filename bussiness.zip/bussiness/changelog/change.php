<?php
date_default_timezone_set("Asia/Kolkata"); 
require_once('../aurthorize/aurthorize.php');
require_once('../dataBaseConnection/DevDbConnect.php');
require_once('../dataBaseConnection/ProdDbConnect.php');
class Change{
public function __construct($hardToken,$softToken,$initial,$final)
{
    
    $ip =Aurthorised::getIPAddress(); 
    $email=Aurthorised::$_adminMail;
$in=json_encode($initial); 
$fl=json_encode($final);
    error_log("Data change from ".$in." to ".$fl." from user ".$email."  with ip address".$ip."\n",3,'../changelog/change.log'); 
}
}
?>