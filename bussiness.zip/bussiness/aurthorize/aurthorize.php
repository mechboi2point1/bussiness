<?php
date_default_timezone_set("Asia/Kolkata"); 
require_once('../dataBaseConnection/DevDbConnect.php');
require_once('../dataBaseConnection/ProdDbConnect.php');
require_once('../serverConfig/serverInIt.php');

class Aurthorised{
public static $_adminMail;
public static $_grantedVia;
public static function isUserAurthorisedForAdminAccess($hardToken,$softToken){
         $server_config=new ServerConfiguration();
         if( $server_config->_environment['type']=='Development'){
            $dbHandeler=DevDataBase::connect();
            
         }
         else if( $server_config->_environment['type']=='Production'){
            $dbHandeler=ProdDataBase::connect();
           
        }
        else{
            $data=Array("serverMessage"=>"No environtment found");
    http_response_code(404);
            echo json_encode($data);
            exit;
        }
        $ip =Aurthorised::getIPAddress(); 
        $sql="select * from sessionTable where tokenHard=:hard and tokenSoft=:soft";
        $query=$dbHandeler->prepare($sql);
       $query->bindValue(':hard',$hardToken);
       $query->bindValue(':soft',$softToken);
       $query->execute();
      
       $rowReturnCount=$query->rowCount();
       
       if($rowReturnCount>0){
        $row=$query->fetch(PDO::FETCH_ASSOC);
        $sExp=date($row['SoftExpiry']);
        $hExp=date($row['hardExpiry']);
        $date_now = date("Y-m-d H:m:s");
       if($ip!=$row['ip']){
           error_log(date("d-m-Y h:i:sa").' Change in ip detected for '.$row['adminEmail'].' it was '.$row['ip'].' and now it is'.$ip."\n",1,'../aurthorize/aurthorized.log');
       }else{
        error_log(date("d-m-Y h:i:sa").' IP address tuned fine for '.$row['adminEmail'].' it was '.$row['ip'].' and now it is'.$ip."\n",3,'../aurthorize/aurthorized.log');
       
       }
        if($date_now<$sExp ){
            $sql="update sessionTable SET hardExpiry=:hExp,SoftExpiry=:sExp where sessionTable.tokenHard = :htoken";
        $query=$dbHandeler->prepare($sql);
        $query->bindValue(':htoken',$hardToken);
        $sExp=Date('y:m:d H:m:s', strtotime('+7 days'));
$hExp=Date('y:m:d H:m:s', strtotime('+14 days'));
        $query->bindValue(':hExp',$hExp);
        $query->bindValue(':sExp',$sExp);
        $query->execute();
        Aurthorised::$_adminMail=$row['adminEmail'];
        Aurthorised::$_grantedVia="Soft token check";
        error_log(date("d-m-Y h:i:sa").' Authentication granted to data base query for user '.$row['adminEmail'].' via'.'Soft token check  with access IP'.$ip."\n",1,'../aurthorize/aurthorized.log');
            return true;
        }
        else if($date_now<$hExp){
            Aurthorised::$_adminMail=$row['adminEmail'];
            Aurthorised::$_grantedVia="Hard token check";
            $sql="update sessionTable SET hardExpiry=:hExp,SoftExpiry=:sExp where sessionTable.tokenHard = :htoken";
            $query->bindValue(':htoken',$hardToken);
            $sExp=Date('y:m:d H:m:s', strtotime('+7 days'));
$hExp=Date('y:m:d H:m:s', strtotime('+14 days'));
        $query->bindValue(':hExp',$hExp);
        $query->bindValue(':sExp',$sExp);
        $query->execute();
        error_log(date("d-m-Y h:i:sa").' Authentication granted to data base query for user '.$row['adminEmail'].' via'.'Hard token check with access IP'.$ip."\n",3,'../aurthorize/aurthorized.log');
        
            return true;
        }
else{
    error_log(date("d-m-Y h:i:sa").' Authentication terminated to data base query for user '.$row['adminEmail'].' via'.'Hard/Soft token check with access IP'.$ip."\n",1,'../aurthorize/aurthorized.log');
       
}

       }
       error_log(date("d-m-Y h:i:sa").' Authentication terminated to data base query for user with hard token as '.$hardToken.' and soft token '.$softToken.'. checked for Hard/Soft token with access IP'.$ip."\n",1,'../aurthorize/aurthorized.log');
        
return false;
}
public static function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
 

}
?>
