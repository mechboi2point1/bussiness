<html>
<head>
    <style>
        .scroll {
            margin:5px;
                padding:5px;
                
                width: 500px;
                height: 110px;
                overflow: auto;
                text-align:justify;

}
.popup {
  position: relative;
  display: inline-block;
  cursor: pointer;
}

/* The actual popup (appears on top) */
.popup .popuptext {
  visibility: hidden;
  width: 160px;
  background-color: #555;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 8px 0;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

/* Toggle this class when clicking on the popup container (hide and show the popup) */
.popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 1s;
  animation: fadeIn 1s
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
  from {opacity: 0;}
  to {opacity: 1;}
}

@keyframes fadeIn {
  from {opacity: 0;}
  to {opacity:1 ;}
}
    </style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
		
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script
  
  src="//cdn.jsdelivr.net/npm/@fingerprintjs/fingerprintjs@3/dist/fp.min.js"
 
></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script>  
	function showMessage(messageHTML) {
		$('#chat-box').append(messageHTML);
	}
    function showAttendanceCap(messageHTML) {
		
    $("#tblEntAttributes tbody").append(messageHTML);
	}
  
    var devId;
    
    initFingerprintJS(); 
    function initFingerprintJS() {
            // Initialize an agent at application startup.
            const fpPromise = FingerprintJS.load()

            // Get the visitor identifier when you need it.
            fpPromise
                .then(fp => fp.get())
                .then(result => {
                    // This is the visitor identifier:
                    const visitorId = result.visitorId
                    devId = visitorId;
                    console.log(devId);
                    

                })

        }
<?php
$config=parse_ini_file("../attendance/attendanceConfig.ini",true);
$host=$config['deploymentServer']['host'];
$port=$config['deploymentServer']['port'];
$link="ws://".$host.":".$port."/qrhoster.php";

setcookie('link', $link);
?>
function getCookie(name) {
    // Split cookie string and get all individual name=value pairs in an array
    var cookieArr = document.cookie.split(";");
    
    // Loop through the array elements
    for(var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");
        
        /* Removing whitespace at the beginning of the cookie name
        and compare it with the given string */
        if(name == cookiePair[0].trim()) {
            // Decode the cookie value and return
            return decodeURIComponent(cookiePair[1]);
        }
    }
    
    // Return null if not found
    return null;
}
var websocket;
	$(document).ready(function(){
        
$link=getCookie('link');

			
                var x;
            function generateQRCode(token) {
              document.getElementById('qr-code').style.display="block";
                var qrtext = token;
                var qr=new QRious({
                    element: document.getElementById('qr-code'),
                    size: 200,
                    value: qrtext
                });
                
                /*qr.set({
                    foreground: 'black',
                    size: 200,
                    value: qrtext
                });*/
                clearInterval(x);
                var countDown = 30;
                x=setInterval(function() {
countDown=countDown-1;
var seconds = countDown;
if(countDown>10){
  document.getElementById("demo").style.color="black";
}
if(countDown==1){
  document.getElementById("demo").innerHTML ="This QR is valid for "+  seconds + " second.";
}
else{
  document.getElementById("demo").innerHTML ="This QR is valid for "+  seconds + " seconds.";
}

if(countDown<=10){
  document.getElementById("demo").style.color="red";
}
if (countDown == 0) {
  var messageJSON = {
				chat_user:'system',
				chat_message:'expired',
        };
        document.getElementById("demo").style.color="red";
    document.getElementById("demo").innerHTML = "QR expired please wait...";
    countDown = 30;      
    websocket.send(JSON.stringify(messageJSON));
    
  }
}, 1000);
            }
		 websocket = new WebSocket($link); 
		websocket.onopen = function(event) { 
			}
		websocket.onmessage = function(event) {
			var Data = JSON.parse(event.data);
            generateQRCode(Data.token);
            
            if(Data.message_type=='done'){
                let audio = new Audio('../attendance/beep.mp3');
                audio.play();
                showAttendanceCap(Data.message);
                generateQRCode(Data.token);
            }
            else if(Data.message_type=='system'){
              //clearInterval(stratTimer());
                let audio = new Audio('../attendance/err.mp3');
                audio.play();
                generateQRCode(Data.token);
                showMessage("<div class='"+Data.message_type+"'>"+Data.message+""+"</div>");
            }
            else if(Data.message_type=='reset'){
              //clearInterval(stratTimer());
              generateQRCode(Data.token);
            }
            else{
              //clearInterval(stratTimer());
                
                generateQRCode(Data.token);
                showMessage("<div class='"+Data.message_type+"'>"+Data.message+""+"</div>")
            }
            
			
		};
		
		websocket.onerror = function(event){
      document.getElementById('connection').innerHTML="We could not load QR. This problem persist's too long please drop an email to falconit@falcon.in";
      document.getElementById('qr-code').style.display="none";
      document.getElementById("demo").style.display="none";
			showMessage("<div class='error'>Problem due to some Error</div>");
		};
		websocket.onclose = function(event){
      document.getElementById("demo").style.display="none";
      document.getElementById('qr-code').style.display="none";
      document.getElementById('connection').innerHTML="Connection lost.";
			showMessage("<div class='chat-connection-ack'>Connection issue.</div>");
   
		}; 
  

  
  
		
		
	});
    



	</script>
  <title>Falcon Attendance System</title>
	</head>
	<body style="align-items: center;">

	<div class="container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Falcon</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      
      <li class="nav-item">
        <a class="nav-link" href="#">Records</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Sales</a>
      </li>
      
    </ul>
  </div>
</nav>
    <div class="card">
        <div class="card-header">Falcon Employee Record system.</div>
        <div class="card-body">
        <p id="demo"></p>
        <p id="connection"></p>
        <canvas height="20%" width="20%"  id="qr-code"></canvas>	
    </div>
    <div class="card-footer">Scan above to exit/enter the work area.</div>
   
    </div>
    </div>
    <hr>
    <div class="container-fluid">
  <div class="row">
    <div class="col-sm-5 col-lg-5">
        <div class="card">
            <div class="card-header">System Information</div>
            <div class="card-body" scroll><div id="chat-box"></div></div>
            <div class="card-footer"><div class="btn form-control btn-danger">Request New QR Manual</div></div>
    </div>
    </div>
    
    <div class="col-sm col-lg">
    <div class="card">
            <div class="card-header">Attendance Information</div>
            <div class="card-body" scroll>
            <div id="att-box"></div>
            <table class="table table-dark table-striped table-active table-bordered table-responsive-lg table-responsive-md table-responsible-sm" id='tblEntAttributes'>
            <thead>
            <tr>
           
            <td>
            Name
            </td>
            <td>
            Email
            </td>
            <td>
            Date and Time
            </td>
            </tr>
            </thead>
            <tbody>

            </tbody>
            </table>
             </div>
            <div class="card-footer"><button onclick="pdf()" class="btn form-control btn-success">Download Attendance Sheet</button></div>
    </div>
    </div>
    
  </div></div> 
       
    </div>
    
  </div>
</div>
	

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script>
     function pdf() {
            html2canvas($('#tblEntAttributes')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("attendance-details-.pdf");
                }
            });
        }
        </script>
</body>
</html>