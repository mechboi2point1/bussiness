<?php
date_default_timezone_set("Asia/Kolkata"); 
class AllowedDevice{
    public static function GETALLALLOWEDDEVICE($device){
$config=parse_ini_file("../attendance/attendanceConfig.ini",true);
$DeviceList=$config['allowedDevice']['id'];
$DeviceList= explode (",", $DeviceList);
for($i=0;$i<sizeof($DeviceList);$i++){
    if($DeviceList[$i]===$device)
{
   return true;

} 
}
return false;

}
}   

?>