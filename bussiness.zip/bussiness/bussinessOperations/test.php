<?php
require_once('./bussiness.php');
$obj=new BussinessRule();
$data=$obj->data1();
header('Content-Type: application/json'); 
//print_r($data);
echo json_encode($data)



?>