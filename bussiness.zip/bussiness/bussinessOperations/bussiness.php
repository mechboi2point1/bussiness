<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "./error.log";
ini_set("log_errors", TRUE);
ini_set('error_log', $log_file);
class BussinessRule{
    public $_universalConfig;
    public $_specialConfig;
    private $_data1;
    private $_dom;
    private $_discountList;
    public function __construct() {
        $data=Array();
        $config=parse_ini_file("../bussinessOperations/bussinessconfig.ini",true);
    
        if($config['discount']['dominant']==='universalDiscount'){
        $this->_dom=1;
        }
        else if($config['discount']['dominant']==='specialDiscount'){
            $this->_dom=2;
            }
            else if($config['discount']['dominant']==='both'){
                $this->_dom=3;
                }
            else{
                $this->_dom=-1;  
            }
            
            $temp=Array("dominance"=>$this->_dom);
            array_push($data,$temp); 
        if(($config['discount']['universalDiscount']=='enable' || $config['discount']['specialDiscount']=='enable') && $this->_dom>0)
        {
           //echo('in first if') ;
        if($config['discount']['universalDiscount']=='enable'){
            //echo(',in Second if') ;
            
            $this->_universalConfig=parse_ini_file("../bussinessOperations/discount.ini",true);
            $allProd=$this->_universalConfig['universalDiscountAllProduct'];
            $totalPay=$this->_universalConfig['universalDiscountOnTotalPay'];
            $allVendor=$this->_universalConfig['discountToAllVendors'];
            $allCustomer=$this->_universalConfig['discountToAllCustomer'];
            //print_r($this->_universalConfig['discountToAllCustomer']);
            $universalData=Array("toAll"=>$allProd,"toTotal"=>$totalPay,"toVendor"=>$allVendor,"toCustomer"=>$allCustomer);
            array_push($data,$universalData);
        }
        if($config['discount']['specialDiscount']=='enable'){
            //echo(',in third if') ;
            $specialData=Array();
            $this->_specialConfig=parse_ini_file("../bussinessOperations/specialDiscount.ini",true)['specialDiscountForProducts'];
            //print_r($this->_specialConfig);
            $productList=$this->_specialConfig['productIds'];
            
            
            $productDiscount=$this->_specialConfig['discountPercentage'];
            if($productList!=null || $productList!=""||$productDiscount!=null||$productDiscount!=""){
            $productDiscount= explode (",", $productDiscount);
            $productList= explode (",", $productList); 
            
            $discountList=Array();
            
            for($i=0;$i<sizeof($productDiscount);$i++){
                $temp=Array($productList[$i]=>$productDiscount[$i]);
                array_push($specialData,$temp);
                $discountList[$productList[$i]]=$productDiscount[$i];
                
            } 
            $this->_discountList=$discountList;
            //echo(sizeof($this->_discountList));
        }
        else{
            $temp=Array("message"=>"No product for discount in list");
            array_push($specialData,$temp); 
        } 
        array_push($data,$specialData); 
            
        }
        
        
    }
    else{
        //No bussiness function is enable
    }
   
    $this->_data1=$data;
}
public function data1(){
return $this->_data1;
}
public function universal(){
    return $this->_universalConfig;
    }
    public function special(){
        return $this->_specialConfig;
        }
public function get_dominanceBussinessScript(){
    return $this->_dom;
    }
    public function getProduct($row){
        
        if($this->_dom==1){
            //echo $row['productSp_vendor'].'>='.$this->_universalConfig['discountToAllVendors']['applyDiscountForMinimumPrice'];
            if($row['productSp_vendor']>=(double)($this->_universalConfig['discountToAllVendors']['applyDiscountForMinimumPrice'])){
            $vendorFinal=$row['productSp_vendor']-($row['productSp_vendor']*(double)((double)($this->_universalConfig['discountToAllVendors']['discountPercentage'])/100));
            $vdis=$this->_universalConfig['discountToAllVendors']['discountPercentage'];
            }
            else{
            $vendorFinal=$row['productSp_vendor'];
            $vdis=0;
               
            }
            if($row['productSp_consumer']>=(double)($this->_universalConfig['discountToAllCustomer']['applyDiscountForMinimumPrice'])||$row['productSp_consumer']>=(double)($this->_universalConfig['universalDiscountAllProduct']['applyDiscountForMinimumPrice'])){
                $consumerFinal=$row['productSp_consumer']-($row['productSp_consumer']*(double)((double)($this->_universalConfig['discountToAllCustomer']['discountPercentage'])/100));
                $cdis=$this->_universalConfig['discountToAllCustomer']['discountPercentage'];
                }
                else{
                    if($row['productSp_consumer']>=(double)($this->_universalConfig['universalDiscountAllProduct']['applyDiscountForMinimumPrice'])){
                    $consumerFinal=$row['productSp_consumer']-($row['productSp_consumer']*(double)((double)($this->_universalConfig['universalDiscountAllProduct']['discountPercentage'])/100));
                    $cdis=$this->_universalConfig['universalDiscountAllProduct']['discountPercentage'];
                    }
                    else{
                        $consumerFinal=$row['productSp_consumer']; 
                        $cdis=0;  
                    }
                }

                $product =Array("id"=>$row['productId'],
                "name"=>$row['productName'],
                "costPrice"=>$row['productCp'],
                "vendorPrice"=>$row['productSp_vendor'],
                "consumerPrice"=>$row['productSp_consumer'],
                "image"=>$row['productImage'],
                "stock"=>$row['stock'],
            "vendorFinal"=>$vendorFinal,
        "consumerFinal"=>$consumerFinal,
        "type"=>$row['type'],
        "vendorBenifit"=>$vdis."%",
        "consumerBenifit"=>$cdis."%");
        return $product;
        }
        else if($this->_dom==2){
          
            $id=$row['productId'];
            
            $dis=$this->_discountList[strval($id)];
            if($dis!=null){
            $consumerFinal=$row['productSp_consumer']-($row['productSp_consumer']*((double)$dis/100));
                    
            $product =Array("id"=>$row['productId'],
                "name"=>$row['productName'],
                "costPrice"=>$row['productCp'],
                "vendorPrice"=>$row['productSp_vendor'],
                "consumerPrice"=>$row['productSp_consumer'],
                "image"=>$row['productImage'],
                "stock"=>$row['stock'],
            "vendorFinal"=>$row['productSp_vendor'],
        "consumerFinal"=>$consumerFinal,
        "type"=>$row['type'],
        "vendorBenifit"=>"0%",
        "consumerBenifit"=>$dis."%");
        return $product;
            }
            else{
                $product =Array("id"=>$row['productId'],
                "name"=>$row['productName'],
                "costPrice"=>$row['productCp'],
                "vendorPrice"=>$row['productSp_vendor'],
                "consumerPrice"=>$row['productSp_consumer'],
                "image"=>$row['productImage'],
                "stock"=>$row['stock'],
            "vendorFinal"=>$row['productSp_vendor'],
        "consumerFinal"=>$row['productSp_consumer'],
        "type"=>$row['type'],
        "vendorBenifit"=>"0%",
        "consumerBenifit"=>"0%");
        return $product; 
            }
        }
        
        else if($this->_dom==3){
            if($row['productSp_vendor']>=(double)($this->_universalConfig['discountToAllVendors']['applyDiscountForMinimumPrice'])){
                $vendorFinal=$row['productSp_vendor']-($row['productSp_vendor']*(double)((double)($this->_universalConfig['discountToAllVendors']['discountPercentage'])/100));
                $vdis=$this->_universalConfig['discountToAllVendors']['discountPercentage'];
                }
                else{
                $vendorFinal=$row['productSp_vendor'];
                $vdis=0;
                   
                }
                $id=$row['productId'];
                $dis=$this->_discountList[strval( $id)];
                if($dis!=null){
                    $consumerFinal=$row['productSp_consumer']-($row['productSp_consumer']*((double)$dis/100));
                }
                else{
                    $consumerFinal=$row['productSp_consumer'];
                    $dis=0;
                }
                
            $product =Array("id"=>$row['productId'],
                "name"=>$row['productName'],
                "costPrice"=>$row['productCp'],
                "vendorPrice"=>$row['productSp_vendor'],
                "consumerPrice"=>$row['productSp_consumer'],
                "image"=>$row['productImage'],
                "stock"=>$row['stock'],
            "vendorFinal"=>$vendorFinal,
        "consumerFinal"=>$consumerFinal,
        "type"=>$row['type'],
    "vendorBenifit"=>$vdis."%",
    "consumerBenifit"=>$dis."%");
            return $product;
        }
        else{
            $product =Array("id"=>$row['productId'],
                "name"=>$row['productName'],
                "costPrice"=>$row['productCp'],
                "vendorPrice"=>$row['productSp_vendor'],
                "consumerPrice"=>$row['productSp_consumer'],
                "image"=>$row['productImage'],
                "stock"=>$row['stock'],
            "vendorFinal"=>$row['productSp_vendor'],
        "consumerFinal"=>$row['productSp_consumer'],
        "type"=>$row['type'],
    "vendorBenifit"=>"0%",
    "consumerBenifit"=>"0%");
            return $product;
        }
        }    



}




?>