<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "./error.log";
ini_set("log_errors", TRUE);
ini_set('error_log', $log_file);
class ServerConfiguration{
    public $_appOwnner;
    public $_docType;
    public $_environment;
    public $_prodDb;
    public $_devDb;
    public $_error;
    
    public function __construct() {
        $config=parse_ini_file("../serverConfig/server.ini",true);
        $this->_appOwnner = $config['ApplicationOwnner'];
        $this->_docType=$config['DocumentType'];
        $this->_environment=$config['environment'];
        $this->_devDb=$config['devdb'];
        $this->_prodDb=$config['proddb'];
        $this->_error==$config['error'];
    }
}
?>