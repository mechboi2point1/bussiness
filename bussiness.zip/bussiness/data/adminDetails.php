<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "./error.log";
ini_set("log_errors", TRUE);
ini_set('error_log', $log_file);
require_once('../aurthorize/aurthorize.php');
require_once('../dataBaseConnection/DevDbConnect.php');
require_once('../dataBaseConnection/ProdDbConnect.php');
require_once('../serverConfig/serverInIt.php');
$hardToken = $_SERVER['HTTP_HARD_TOKEN'];
$softToken = $_SERVER['HTTP_SOFT_TOKEN'];

if(Aurthorised::isUserAurthorisedForAdminAccess($hardToken,$softToken)){
    $server_config=new ServerConfiguration();
         if( $server_config->_environment['type']=='Development'){
            $dbHandeler=DevDataBase::connect();
            
         }
         else if( $server_config->_environment['type']=='Production'){
            $dbHandeler=ProdDataBase::connect();
           
        }
        else{
            $data=Array("serverMessage"=>"No environtment found");
    http_response_code(404);
            echo json_encode($data);
            exit;
        }
   $sql="select * from adminTable where email=:email";
        $query=$dbHandeler->prepare($sql);
       $query->bindValue(':email',Aurthorised::$_adminMail);
       $query->execute();
       $rowReturnCount=$query->rowCount();
       if($rowReturnCount>0){
           
        $row=$query->fetch(PDO::FETCH_ASSOC);
        if($row['blocked']==0){
            header('Content-Type: application/json'); 
            $serverMessage="Access granted after ".Aurthorised::$_grantedVia;
        $data=Array("serverMessage"=>$serverMessage,"name"=>$row['email'],"name"=>$row['name'],"joined"=>$row['joiningDate']);
    http_response_code(200);
    echo json_encode($data);
    exit;
        }
        header('Content-Type: application/json'); 
        http_response_code(202);
        echo json_encode("Your account is blocked. Contact Application Ownner.");
        exit; 
}
}
else{
    http_response_code(404);
    header('Content-Type: application/json'); 
        echo json_encode('You are not eligible to access the Admin profile. If more attemps are taken for access, your IP address will be suspended. If your are aurthorized to access this section contact Application Ownner to get your access token issued.');
        
        exit; 
}
?>