<?php
date_default_timezone_set("Asia/Kolkata"); 
require_once('../serverConfig/serverInIt.php');
$config=parse_ini_file("../serverConfig/server.ini",true);

function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$ip = getIPAddress();  
$envType=$config['environment']['type'];
if($envType==''||$envType==null){
    http_response_code(500);
    $reportTo=$config['error']['errorMailsTo'];
  mail($reportTo,'Some error Occured','Hi, Some error encountered while Fetching evn config file authenticate.php/9');
    
    error_log(date("d-m-Y h:i:sa").' Environtment.type missing it should be set to devlopment for devlopment activities and production for service activities.'."\n",3,"../authenticate/error.log");
    echo json_encode("Server cannot take request at this moment. Contact Application ownner.");
     
    exit;
}
if($envType=='Development'){
    //echo('Application pointed to Development Region');
    require_once('../dataBaseConnection/DevDbConnect.php');
}
if($envType=='Production'){
    //echo('Application pointed to Production Region');
    require_once('../dataBaseConnection/ProdDbConnect.php');
}
$dbHandeler=null;
try{
    $server_config=new ServerConfiguration();
    if( $server_config->_environment['type']=='Development'){
       $dbHandeler=DevDataBase::connect();
       
    }
    else if( $server_config->_environment['type']=='Production'){
       $dbHandeler=ProdDataBase::connect();
      
   }
   else{
       $data=Array("serverMessage"=>"No environtment found");
http_response_code(404);
       echo json_encode($data);
       exit;
   }
         
    //$dbHandeler=DevDataBase::connect();
  }
  catch(PDOException $exp){
  http_response_code(500);
  $reportTo=$config['error']['errorMailsTo'];
  mail($reportTo,'Some error Occured','Hi, Some error encountered while Connecting Data Base this is authenticate.php/33');
    echo json_encode("Internal server error1");
      exit;
  }


if($_SERVER['REQUEST_METHOD'] ==='OPTIONS'){
    header('Access-Control-Allow-Methods: GET,OPTION');
    header('Access-Control-Allow-Headers:Content-type,Authorization');
    header('Access-Control-Max-Age:86400');
    http_response_code(200);
  echo json_encode("Fine");
    exit;
}
header("Content-Type: application/json", true);
$_POST = json_decode(file_get_contents('php://input'),true);

$requestType=$_SERVER['REQUEST_METHOD'];
if($requestType==='POST'){
    $email=$_POST['email'];
    $password=$_POST['password'];
    $devId=$_POST['device'];
   
    if($email==null || $email==''||$password==null|| $password==''){
        http_response_code(400);
        header('Content-Type: application/json'); 
        echo json_encode('Some values are missing. Email and Password Required to Authenticate.'); 
        exit; 
    }
    else{
    
    header('Content-Type: application/json'); 
    
    $sql='select * from adminTable where email=:email';
       $query=$dbHandeler->prepare($sql);
       $query->bindValue(':email',strtolower($email));
       
       $query->execute();
       $rowReturnCount=$query->rowCount();
       if($rowReturnCount==0){
        http_response_code(202);
        echo json_encode('No admin found with '.$email);
        error_log(date("d-m-Y h:i:sa").' User '.$email.' not found in '.$envType."\n",3,"../authenticate/failed.log") ;
        exit; 
       }
else{
    $row=$query->fetch(PDO::FETCH_ASSOC);
   //print_r($row);
    $passwordFromDb=$row['password'];
    if($password==$passwordFromDb ||$password==$row['pin']){
        //print_r('Password match');
       try{
        
        
        $emailFromDb=$row['email'];
        date("Y-m-d H:m:s");
        
//print_r('119');

        $query=$dbHandeler->prepare('UPDATE adminTable SET device = :device WHERE email=:email');
        //print_r('122');
        $query->bindValue(':email',strtolower($emailFromDb));
        $query->bindValue(':device',$devId);
        $query->execute();
        //print_r('126');
        $rowReturnCount=$query->rowCount();
        //print_r('119 '.$rowReturnCount);
        if($rowReturnCount>0){
            $res="Hi ".$row['name'].", We Registered your device now. For any issues please raise concern to Falcon IT&Data Team.";
          //  print_r('131'); 
    http_response_code(200);
    echo json_encode($res); 
    error_log(date("d-m-Y h:i:sa").' User '.$email.' got registered in  '.$envType."\n",3,"../employee/emp.log") ;
    exit; 
        }
        else{
            if($devId===$row['device']){
                http_response_code(202);
                echo json_encode("Hi ".$row['name'].', your device got re-registed.'); 
                error_log(date("d-m-Y h:i:sa").' User '.$email.' device re registered in '.$envType."\n",3,"../employee/emp.log") ;
                exit;   
            }
            http_response_code(201);
            echo json_encode('Could not register your device.'); 
            error_log(date("d-m-Y h:i:sa").' User '.$email.' device could not be registered in '.$envType."\n",3,"../employee/emp.log") ;
            exit; 
        }   
    }catch(Exception $e){
        error_log(date("d-m-Y h:i:sa").$e,1,"../authenticate/error.log");
        exit;
    }     
}
else{
    http_response_code(400);
    echo json_encode('Wrong password for '.$email); 
    error_log(date("d-m-Y h:i:sa").' User '.$email.' authentication not allowed to '.$envType."\n",3,"../authenticate/failed.log") ;
    exit; 
}

}
    
    }
}
else{
    http_response_code(405);
    header('Content-Type: application/json'); 
    $m=Array('errorMessage'=>'Method POST Expected but '.$requestType.' was found');
    echo json_encode($m);
    exit;
}




?>