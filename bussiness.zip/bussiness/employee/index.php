<html>

<head>
<title>Falcon AtQR Scanner</title>
    <style link="./qr.css"></style>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   

    <script src="./qrScan.js"></script>

</head>

<body>
<h1 style="text-align: center;">Falcon Employee Attendance Management System</h1>
    <video id="preview"></video>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>

    <script type="text/javascript">
    var devId;
     $(document).ready(function() {
                    var websocket = new WebSocket("ws://192.168.43.51:443/qrhoster.php");
                    websocket.onopen = function(event) {
                    }
                
        let scanner = new Instascan.Scanner({
            video: document.getElementById('preview')
        });
        scanner.addListener('scan', function(content) {
            var audio = new Audio('../employee/beep.mp3');
            audio.play();
            var fidpin=prompt('Enter your Falcon ID-Pin');
            var messageJSON = {
				chat_user:fidpin,
				chat_message:content,
                
			};
            
            websocket.send(JSON.stringify(messageJSON));
        });
        Instascan.Camera.getCameras().then(function(cameras) {
            if (cameras.length > 0) {
                scanner.start(cameras[0]);
            } else {
                console.error('No scanner found.');
            }
        }).catch(function(e) {
            console.error(e);
        });
    });
    
       
    </script>
</body>

</html>