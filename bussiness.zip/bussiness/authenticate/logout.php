<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "../log/error.log";
ini_set("log_errors", TRUE);
ini_set('error_log', $log_file);
require_once('../dataBaseConnection/DevDbConnect.php');
require_once('../dataBaseConnection/ProdDbConnect.php');
require_once('../serverConfig/serverInIt.php');
$hardToken = $_SERVER['HTTP_HARD_TOKEN'];
$softToken = $_SERVER['HTTP_SOFT_TOKEN'];
if($hardToken!=null&&$softToken!=null){
    $server_config=new ServerConfiguration();
    if( $server_config->_environment['type']=='Development'){
       $dbHandeler=DevDataBase::connect();
       
    }
    else if( $server_config->_environment['type']=='Production'){
       $dbHandeler=ProdDataBase::connect();
      
   }
   else{
       $data=Array("serverMessage"=>"No environtment found");
       
http_response_code(404);
       echo json_encode($data);
       exit;
   }
    
    
   $sql="select * from sessionTable where tokenHard=:hard and tokenSoft=:soft";
   $query=$dbHandeler->prepare($sql);
  $query->bindValue(':hard',$hardToken);
  $query->bindValue(':soft',$softToken);
  $query->execute();
 
  $rowReturnCount=$query->rowCount();
  
  if($rowReturnCount>0){
   $row=$query->fetch(PDO::FETCH_ASSOC);
   $sExp=date($row['SoftExpiry']);
   $hExp=date($row['hardExpiry']);
   $date_now = date("Y-m-d H:m:s");
  
   if($date_now<$sExp){
       $sql="DELETE FROM sessionTable WHERE tokenHard=:hard and tokenSoft=:soft";
   $query=$dbHandeler->prepare($sql);
   $query->bindValue(':hard',$hardToken);
   $query->bindValue(':soft',$softToken);
   $query->execute();
   header('Content-Type: application/json'); 
        http_response_code(200);
        echo json_encode("Logged out from session. And token are dummped safely for ever");
        exit; 
   }
   else if($date_now<$hExp){
    $sql="DELETE FROM sessionTable WHERE tokenHard=:hard and tokenSoft=:soft";
    $query=$dbHandeler->prepare($sql);
    $query->bindValue(':htoken',$hardToken);
    $query->bindValue(':soft',$softToken);
    $query->execute();
    header('Content-Type: application/json'); 
         http_response_code(200);
         echo json_encode("Logged out from session. And token are dummped safely for ever");
         exit;
   }


  }
  header('Content-Type: application/json'); 
  http_response_code(404);
  echo json_encode("Logging failed. Contact Admin As soon as possible.");
  exit;
}
?>