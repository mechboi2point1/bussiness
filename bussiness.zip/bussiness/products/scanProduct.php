<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "./error.log";

// setting error logging to be active
ini_set("log_errors", TRUE); 
  
// setting the logging file in php.ini
ini_set('error_log', $log_file);
require_once('../aurthorize/aurthorize.php');
require_once('../dataBaseConnection/DevDbConnect.php');
require_once('../dataBaseConnection/ProdDbConnect.php');
require_once('../serverConfig/serverInIt.php');
require_once('../bussinessOperations/bussiness.php');
$hardToken = $_SERVER['HTTP_HARD_TOKEN'];
$softToken = $_SERVER['HTTP_SOFT_TOKEN'];
$server_config=new ServerConfiguration();
    if( $server_config->_environment['type']=='Development'){
       $dbHandeler=DevDataBase::connect();
       
    }
    else if( $server_config->_environment['type']=='Production'){
       $dbHandeler=ProdDataBase::connect();
      
   }
   else{
       $data=Array("serverMessage"=>"No environtment found");
http_response_code(404);
       echo json_encode($data);
       exit;
   }
if(Aurthorised::isUserAurthorisedForAdminAccess($hardToken,$softToken)){
    $sql='select * from productTable';
    $query=$dbHandeler->prepare($sql);
    $query->execute();
    $rowReturnCount=$query->rowCount();
    if($rowReturnCount>0){
        $data=Array();
        $bussiness=new BussinessRule();
        while($row=$query->fetch(PDO::FETCH_ASSOC)){
            

            $product =$bussiness->getProduct($row);
            
            array_push($data,$product);
            
          }
          header('Content-Type: application/json'); 
          http_response_code(200);
         echo json_encode($data);
         exit;     
    }
    else{
        header('Content-Type: application/json'); 
        http_response_code(405);
       echo json_encode("No product found");
       exit;
    }

}
else{
    header('Content-Type: application/json'); 
    http_response_code(403);
    echo json_encode('Forbiden to access product data, trying illegal access to company\'s intelectuall data is offensive.'); 
 
    exit; 
}
?>