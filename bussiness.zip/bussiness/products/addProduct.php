<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "./error.log";

// setting error logging to be active
ini_set("log_errors", TRUE); 
  
// setting the logging file in php.ini
ini_set('error_log', $log_file);
require_once('../aurthorize/aurthorize.php');
require_once('../dataBaseConnection/DevDbConnect.php');
require_once('../dataBaseConnection/ProdDbConnect.php');
require_once('../serverConfig/serverInIt.php');
$hardToken = $_SERVER['HTTP_HARD_TOKEN'];
$softToken = $_SERVER['HTTP_SOFT_TOKEN'];
try{
    $server_config=new ServerConfiguration();
    if( $server_config->_environment['type']=='Development'){
       $dbHandeler=DevDataBase::connect();
       
    }
    else if( $server_config->_environment['type']=='Production'){
       $dbHandeler=ProdDataBase::connect();
      
   }
   else{
       $data=Array("serverMessage"=>"No environtment found");
http_response_code(404);
       echo json_encode($data);
       exit;
   }
         
    //$dbHandeler=DevDataBase::connect();
  }
  catch(PDOException $exp){
  http_response_code(500);
  $reportTo=$config['error']['errorMailsTo'];
  mail($reportTo,'Some error Occured','Hi, Some error encountered while Connecting Data Base this is authenticate.php/33');
    echo json_encode("Internal server error");
      exit;
  }
$server_config=new ServerConfiguration();
    if( $server_config->_environment['type']=='Development'){
       $dbHandeler=DevDataBase::connect();
       
    }
    else if( $server_config->_environment['type']=='Production'){
       $dbHandeler=ProdDataBase::connect();
      
   }
   else{
       $data=Array("serverMessage"=>"No environtment found");
http_response_code(404);
       echo json_encode($data);
       exit;
   }
$_POST = json_decode(file_get_contents('php://input'), true);
$requestType=$_SERVER['REQUEST_METHOD'];
if($requestType=="POST"){
if(Aurthorised::isUserAurthorisedForAdminAccess($hardToken,$softToken)){
    $sql='insert into productTable (productName,productCp,productSp_vendor,productSp_consumer,productImage,stock,type) values (:name,:cp,:spv,:spc,:img,:stk,:type)';
    $query=$dbHandeler->prepare($sql);
    $query->bindValue(':name',$_POST['name']);
        $query->bindValue(':cp',$_POST['costPrice']);
        $query->bindValue(':spv',$_POST['vendorPrice']);
        $query->bindValue(':spc',$_POST['consumerPrice']);
        $query->bindValue(':img',$_POST['image']);
        $query->bindValue(':stk',$_POST['stock']);
        $query->bindValue(':type',$_POST['type']);
    $query->execute();
    
    $rowReturnCount=$query->rowCount();
    if($rowReturnCount>0){
        $last_id = $dbHandeler->lastInsertId();
        $data=Array("serverMessage"=>"Loaded new product in ".$server_config->_environment['type']." data base.","generatedProductId"=>$last_id);
        
          header('Content-Type: application/json'); 
          http_response_code(200);
         echo json_encode($data);
         exit;     
    }
    else{
        header('Content-Type: application/json'); 
        http_response_code(405);
       echo json_encode("No product found");
       exit;
    }

}
else{
    header('Content-Type: application/json'); 
    http_response_code(403);
    echo json_encode('You are not aurthorized to make changes in company\'s Data base'); 
 
    exit; 
}
}
else{
    header('Content-Type: application/json'); 
    http_response_code(400);
    echo json_encode('POST IS EXPECTED BUT '.$requestType." WAS FOUND"); 
 
    exit;   
}
?>