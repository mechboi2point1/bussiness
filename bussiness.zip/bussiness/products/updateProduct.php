<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "../log/error.log";

// setting error logging to be active
ini_set("log_errors", TRUE); 
  
// setting the logging file in php.ini
ini_set('error_log', $log_file);
require_once('../changelog/change.php');
require_once('../aurthorize/aurthorize.php');
require_once('../dataBaseConnection/DevDbConnect.php');
require_once('../dataBaseConnection/ProdDbConnect.php');
require_once('../serverConfig/serverInIt.php');
$hardToken = $_SERVER['HTTP_HARD_TOKEN'];
$softToken = $_SERVER['HTTP_SOFT_TOKEN'];
try{
    $server_config=new ServerConfiguration();
    if( $server_config->_environment['type']=='Development'){
       $dbHandeler=DevDataBase::connect();
       
    }
    else if( $server_config->_environment['type']=='Production'){
       $dbHandeler=ProdDataBase::connect();
      
   }
   else{
       $data=Array("serverMessage"=>"No environtment found");
http_response_code(404);
       echo json_encode($data);
       exit;
   }
         
    //$dbHandeler=DevDataBase::connect();
  }
  catch(PDOException $exp){
  http_response_code(500);
  $reportTo=$config['error']['errorMailsTo'];
  mail($reportTo,'Some error Occured','Hi, Some error encountered while Connecting Data Base this is authenticate.php/33');
    echo json_encode("Internal server error");
      exit;
  }
$server_config=new ServerConfiguration();
    if( $server_config->_environment['type']=='Development'){
       $dbHandeler=DevDataBase::connect();
       
    }
    else if( $server_config->_environment['type']=='Production'){
       $dbHandeler=ProdDataBase::connect();
      
   }
   else{
       $data=Array("serverMessage"=>"No environtment found");
http_response_code(404);
       echo json_encode($data);
       exit;
   }
$_POST = json_decode(file_get_contents('php://input'), true);
$requestType=$_SERVER['REQUEST_METHOD'];
if($requestType=="POST"){
if(Aurthorised::isUserAurthorisedForAdminAccess($hardToken,$softToken)){
    $sql='select * from productTable where productId=:id';
    $query=$dbHandeler->prepare($sql);
    $query->bindValue(':id',$_POST['id']);
    $query->execute();
    $rowReturnCount=$query->rowCount();
    if($rowReturnCount>0){
        $row=$query->fetch(PDO::FETCH_ASSOC);
        $initProduct =Array("id"=>$row['productId'],
            "name"=>$row['productName'],
            "costPrice"=>$row['productCp'],
            "vendorPrice"=>$row['productSp_vendor'],
            "consumerPrice"=>$row['productSp_consumer'],
            "image"=>$row['productImage'],
            "stock"=>$row['stock']);
    $sql='update productTable SET productName=:name,productCp=:cp,productSp_vendor=:spv,productSp_consumer=:spc,productImage=:img,stock=:stk where productId=:id';
    
    $query=$dbHandeler->prepare($sql);
    $query->bindValue(':id',$_POST['id']);
    if($_POST['name']==null || $_POST['name']==""){
        
        $query->bindValue(':name',$row['productName']);
    }
    else{
        $query->bindValue(':name',$_POST['name']);
    }
    if($_POST['costPrice']==null){
       
        $query->bindValue(':cp', $row['productCp']);
    }
    else{
        $query->bindValue(':cp',$_POST['costPrice']);
    }
       if($_POST['vendorPrice']==null){
        $query->bindValue(':spv',$row['productSp_vendor']);
       }
       else{
        $query->bindValue(':spv',$_POST['vendorPrice']);
       }
        if($_POST['consumerPrice']==null){
            $query->bindValue(':spc',$row['productSp_consumer']);
        }
        else{
            $query->bindValue(':spc',$_POST['consumerPrice']);
        }
        if($_POST['image']==null || $_POST['image']==""){
            
            $query->bindValue(':img',$row['productImage']);
        }
        else{
            $query->bindValue(':img',$_POST['image']);
        }
        if($_POST['stock']==null){
            $query->bindValue(':stk',$row['stock']);
        }
        else{
            $query->bindValue(':stk',$_POST['stock']);
        }
        
        
        
    $query->execute();
    
    $sql='select * from productTable where productId=:id';
    $query=$dbHandeler->prepare($sql);
    $query->bindValue(':id',$_POST['id']);
    $query->execute();
    $rowReturnCount=$query->rowCount();
    if($rowReturnCount>0){
        $row1=$query->fetch(PDO::FETCH_ASSOC);
        $finalProduct =Array("id"=>$row1['productId'],
            "name"=>$row1['productName'],
            "costPrice"=>$row1['productCp'],
            "vendorPrice"=>$row1['productSp_vendor'],
            "consumerPrice"=>$row1['productSp_consumer'],
            "image"=>$row1['productImage'],
            "stock"=>$row1['stock']);
    }
    new Change($hardToken,$softToken,$row,$row1);
    header('Content-Type: application/json');
    $data=Array();
    $in=Array("previousDetails"=>$initProduct);
    $curr=Array("currentDetails"=>$finalProduct);
    $ser=Array("serverMessage"=>"Updated product details in  ".$server_config->_environment['type']);
    array_push($data,$ser);
    array_push($data,$in);
    array_push($data,$curr); 
    http_response_code(404);
    
   echo json_encode($data);
   exit;
}
else{
    header('Content-Type: application/json'); 
    http_response_code(404);

   echo json_encode("No product found with provided id ".$_POST['id']);
   exit; 
}

}
else{
    header('Content-Type: application/json'); 
    http_response_code(403);
    echo json_encode('You are not aurthorized to make changes in company\'s Data base'); 
 
    exit; 
}
}
else{
    header('Content-Type: application/json'); 
    http_response_code(400);
    echo json_encode('POST IS EXPECTED BUT '.$requestType." WAS FOUND"); 
 
    exit;   
}
?>