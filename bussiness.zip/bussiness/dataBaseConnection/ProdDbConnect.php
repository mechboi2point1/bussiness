<?php
date_default_timezone_set("Asia/Kolkata"); 
$log_file = "./dberror.log";
ini_set("log_errors", TRUE);
ini_set('error_log', $log_file);
class ProdDataBase{
    private static $connectionVariable;
    public static function connect(){
        $config=parse_ini_file("../serverConfig/server.ini",true);
      $envType=$config['environment']['type'];
        if($envType=='Production'){
            $dataBaseConfig=$config['proddb'];
            $host=$dataBaseConfig['host'];
            $port=$dataBaseConfig['port'];
            $dbName=$dataBaseConfig['dbname'];
            $password=$dataBaseConfig['password'];
            $username=$dataBaseConfig['username'];
            if(self::$connectionVariable===null){
              self::$connectionVariable = new PDO('mysql:host='.$host.';dbname='.$dbName,$username,$password);
              self::$connectionVariable->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
              self::$connectionVariable->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
              
            }
          }
          else{
            error_log('Environtment.type missing it should be set to development for devlopment activities and production for service activities. Failed to connect to Prod Data Base');
      
          }
    
      return self::$connectionVariable;
    }
  }

?>